#The test for P-I cosnsists of the below 3 tasks.

##Task 1
Produce a funtion that returns a string from 2 initial strings applying various rules.


##Task 2
Produce a funtion that returns an array from 2 initial arrays by shuffling them together.

##Task 3
Produce a funtion that reverses only the odd characters in a string, then use it in an AngularJS app with and without creating a custom directive.

---
Please run index.html in a browser to see the results.
